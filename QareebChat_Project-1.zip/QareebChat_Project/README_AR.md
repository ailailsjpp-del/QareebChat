# قريب Chat — مشروع البداية

هذه ملفات مصدر Flutter لتطبيق مراسلة خاص، وليست APK جاهزاً ولا خدمة مستضافة.

## ما يعمل بعد ضبط Firebase
- تسجيل Google دون رقم هاتف.
- ملف مستخدم ويوزر فريد.
- البحث باليوزر.
- رسائل نصية لحظية بين مستخدمين عبر Cloud Firestore.
- نشر حالات نصية وروابط.

## إعداد التشغيل
1. أنشئ مشروعاً في https://console.firebase.google.com
2. فعّل Authentication > Sign-in method > Google.
3. أنشئ Cloud Firestore Database.
4. على كمبيوتر عليه Flutter SDK نفّذ:
   dart pub global activate flutterfire_cli
   flutterfire configure
   flutter pub get
5. اتبع إعداد Firebase Android وأضف بصمة SHA-1/SHA-256 إذا طلبت.
6. انشر قواعد `firestore.rules` بعد مراجعتها.
7. شغّل `flutter run`، ولإنشاء APK استخدم `flutter build apk --release`.

## حدود هذه النسخة
- المكالمات الصوتية والفيديو غير منفذة بعد؛ تحتاج WebRTC وإشارات اتصال وخادم STUN/TURN.
- الحالات حالياً نص وروابط؛ رفع الصور والفيديو يحتاج Firebase Storage وقواعد مناسبة.
- لا يمكن لأي شخص آخر مراسلتك إلا بعد أن يثبت التطبيق ويسجّل بحسابه، وبعد ضبط Firebase ونشر التطبيق.
- قبل نشر عام، يجب مراجعة قواعد الأمان والخصوصية واختبارها. لا تضع كلمات مرور أو مفاتيح خاصة في الكود.
