import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

const green = Color(0xFF20C86B);
const bg = Color(0xFF0B1114);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const QareebApp());
}

class QareebApp extends StatelessWidget {
  const QareebApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'قريب Chat', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.dark),
      scaffoldBackgroundColor: bg, useMaterial3: true),
    home: const Gate(),
  );
}

class Gate extends StatelessWidget {
  const Gate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (_, s) {
      if (s.connectionState == ConnectionState.waiting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      return s.data == null ? const LoginPage() : const MainPage();
    });
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  bool busy = false; String error = '';
  Future<void> login() async {
    setState(() { busy = true; error = ''; });
    try {
      final account = await GoogleSignIn().signIn();
      if (account == null) { setState(() => busy = false); return; }
      final a = await account.authentication;
      final credential = GoogleAuthProvider.credential(accessToken: a.accessToken, idToken: a.idToken);
      final result = await FirebaseAuth.instance.signInWithCredential(credential);
      final u = result.user!;
      await FirebaseFirestore.instance.collection('users').doc(u.uid).set({
        'uid': u.uid, 'displayName': u.displayName ?? 'مستخدم',
        'email': u.email ?? '', 'photoURL': u.photoURL ?? '',
        'username': '', 'lastSeen': FieldValue.serverTimestamp()
      }, SetOptions(merge: true));
    } catch (e) { setState(() => error = 'فشل الدخول. تأكد من إعداد Firebase وGoogle.\\n$e'); }
    if (mounted) setState(() => busy = false);
  }
  @override
  Widget build(BuildContext context) => Scaffold(body: Center(child: Padding(
    padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
      const CircleAvatar(radius: 42, backgroundColor: green, child: Icon(Icons.forum, size: 42, color: Colors.black)),
      const SizedBox(height: 18), const Text('قريب Chat', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8), const Text('دردش مع الناس باستخدام اليوزر', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 24), SizedBox(width: double.infinity, child: FilledButton.icon(
        onPressed: busy ? null : login, icon: const Icon(Icons.login),
        label: Text(busy ? 'جارٍ الدخول...' : 'تسجيل الدخول باستخدام Google'))),
      if (error.isNotEmpty) Text(error, style: const TextStyle(color: Colors.redAccent)),
      const SizedBox(height: 10), const Text('لا يحتاج رقم هاتف؛ يلزم إعداد Firebase أولاً.', textAlign: TextAlign.center)
    ]))));

class MainPage extends StatefulWidget {
  const MainPage({super.key});
  @override State<MainPage> createState() => _MainPageState();
}
class _MainPageState extends State<MainPage> {
  int index = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [const ChatsPage(), const SearchPage(), const StatusPage(), const ProfilePage()];
    return Scaffold(
      appBar: AppBar(title: const Text('قريب Chat', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [IconButton(onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout))]),
      body: pages[index],
      bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'الدردشات'),
          NavigationDestination(icon: Icon(Icons.search), label: 'بحث'),
          NavigationDestination(icon: Icon(Icons.circle_outlined), label: 'الحالات'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ]),
    );
  }
}

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override State<SearchPage> createState() => _SearchPageState();
}
class _SearchPageState extends State<SearchPage> {
  final c = TextEditingController(); String q = '';
  Future<void> startChat(Map<String,dynamic> p) async {
    final me = FirebaseAuth.instance.currentUser!;
    if (p['uid'] == me.uid) return;
    final ids = [me.uid, p['uid'].toString()]..sort();
    final id = ids.join('_');
    await FirebaseFirestore.instance.collection('chats').doc(id).set({
      'members': ids,
      'names': {me.uid: me.displayName ?? 'أنا', p['uid']: p['displayName'] ?? 'مستخدم'},
      'lastMessage': '', 'updatedAt': FieldValue.serverTimestamp()
    }, SetOptions(merge: true));
    if (!mounted) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(chatId: id, title: p['displayName'] ?? 'مستخدم')));
  }
  @override
  Widget build(BuildContext context) => Column(children: [
    Padding(padding: const EdgeInsets.all(14), child: TextField(controller: c,
      onChanged: (v) => setState(() => q = v.trim().replaceFirst('@','').toLowerCase()),
      decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'ابحث باليوزر، مثلاً ali_123'))),
    Expanded(child: q.isEmpty ? const Center(child: Text('اكتب يوزر للبحث عن مستخدمين'))
      : StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
        stream: FirebaseFirestore.instance.collection('users').where('username', isEqualTo: q).limit(20).snapshots(),
        builder: (_, s) {
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          if (s.data!.docs.isEmpty) return const Center(child: Text('لا يوجد مستخدم بهذا اليوزر'));
          return ListView(children: s.data!.docs.map((d) {
            final p = d.data();
            return ListTile(leading: const CircleAvatar(child: Icon(Icons.person)),
              title: Text(p['displayName'] ?? 'مستخدم'), subtitle: Text('@${p['username'] ?? ''}'),
              trailing: const Icon(Icons.chat, color: green), onTap: () => startChat(p));
          }).toList());
        }))
  ]);
}

class ChatsPage extends StatelessWidget {
  const ChatsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    return StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
      stream: FirebaseFirestore.instance.collection('chats').where('members', arrayContains: uid).snapshots(),
      builder: (_, s) {
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        final docs = s.data!.docs;
        if (docs.isEmpty) return const Center(child: Text('لا توجد محادثات. افتح البحث وابحث عن يوزر.'));
        return ListView(children: docs.map((d) {
          final x = d.data(); final members = List<String>.from(x['members'] ?? []);
          final other = members.firstWhere((v) => v != uid, orElse: () => uid);
          final names = Map<String,dynamic>.from(x['names'] ?? {});
          return ListTile(leading: const CircleAvatar(child: Icon(Icons.person)),
            title: Text('${names[other] ?? 'محادثة'}'), subtitle: Text('${x['lastMessage'] ?? ''}'),
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => ChatPage(chatId: d.id, title: '${names[other] ?? 'محادثة'}'))));
        }).toList());
      });
  }
}

class ChatPage extends StatefulWidget {
  final String chatId, title;
  const ChatPage({super.key, required this.chatId, required this.title});
  @override State<ChatPage> createState() => _ChatPageState();
}
class _ChatPageState extends State<ChatPage> {
  final c = TextEditingController(); bool busy = false;
  Future<void> send() async {
    final text = c.text.trim(); if (text.isEmpty || busy) return;
    setState(() => busy = true); c.clear();
    final db = FirebaseFirestore.instance; final chat = db.collection('chats').doc(widget.chatId);
    await chat.collection('messages').add({'senderId': FirebaseAuth.instance.currentUser!.uid,
      'text': text, 'type': 'text', 'createdAt': FieldValue.serverTimestamp()});
    await chat.set({'lastMessage': text, 'updatedAt': FieldValue.serverTimestamp()}, SetOptions(merge: true));
    if (mounted) setState(() => busy = false);
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.title), actions: [
      IconButton(onPressed: () => showCallNote(context, 'صوتية'), icon: const Icon(Icons.call)),
      IconButton(onPressed: () => showCallNote(context, 'فيديو'), icon: const Icon(Icons.videocam)),
    ]),
    body: Column(children: [
      Expanded(child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
        stream: FirebaseFirestore.instance.collection('chats').doc(widget.chatId)
          .collection('messages').orderBy('createdAt').snapshots(),
        builder: (_, s) {
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final docs = s.data!.docs;
          return ListView(padding: const EdgeInsets.all(12), children: docs.map((d) {
            final m = d.data(); final mine = m['senderId'] == FirebaseAuth.instance.currentUser!.uid;
            return Align(alignment: mine ? Alignment.centerLeft : Alignment.centerRight, child: Container(
              margin: const EdgeInsets.symmetric(vertical: 4), padding: const EdgeInsets.all(12),
              constraints: const BoxConstraints(maxWidth: 300),
              decoration: BoxDecoration(color: mine ? const Color(0xFF075E4A) : const Color(0xFF20292E),
                borderRadius: BorderRadius.circular(16)), child: Text('${m['text'] ?? ''}')));
          }).toList());
        })),
      SafeArea(child: Padding(padding: const EdgeInsets.all(8), child: Row(children: [
        Expanded(child: TextField(controller: c, onSubmitted: (_) => send(), minLines: 1, maxLines: 4,
          decoration: InputDecoration(hintText: 'مراسلة', filled: true, fillColor: const Color(0xFF20292E),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(26), borderSide: BorderSide.none)))),
        IconButton(onPressed: busy ? null : send, icon: const Icon(Icons.send, color: green))
      ])))
    ]));
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override State<ProfilePage> createState() => _ProfilePageState();
}
class _ProfilePageState extends State<ProfilePage> {
  final c = TextEditingController(); String note = ''; bool busy = false;
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    final u = FirebaseAuth.instance.currentUser!;
    final d = await FirebaseFirestore.instance.collection('users').doc(u.uid).get();
    c.text = d.data()?['username'] ?? ''; if (mounted) setState(() {});
  }
  Future<void> save() async {
    final name = c.text.trim().replaceFirst('@','').toLowerCase();
    if (!RegExp(r'^[a-z0-9_]{4,20}$').hasMatch(name)) { setState(() => note = 'اليوزر 4-20 حرفاً إنجليزي أو رقم أو _'); return; }
    setState(() { busy = true; note = ''; });
    final db = FirebaseFirestore.instance; final uid = FirebaseAuth.instance.currentUser!.uid;
    try {
      await db.runTransaction((t) async {
        final userRef = db.collection('users').doc(uid); final u = await t.get(userRef);
        final handleRef = db.collection('usernames').doc(name); final taken = await t.get(handleRef);
        if (taken.exists && taken.data()?['uid'] != uid) throw Exception('اليوزر محجوز');
        final old = u.data()?['username'];
        if (old != null && old != '' && old != name) t.delete(db.collection('usernames').doc(old));
        t.set(handleRef, {'uid': uid}); t.set(userRef, {'username': name}, SetOptions(merge: true));
      });
      setState(() => note = 'تم حفظ @$name');
    } catch (e) { setState(() => note = e.toString().replaceFirst('Exception: ','')); }
    if (mounted) setState(() => busy = false);
  }
  @override
  Widget build(BuildContext context) {
    final u = FirebaseAuth.instance.currentUser!;
    return ListView(padding: const EdgeInsets.all(20), children: [
      CircleAvatar(radius: 36, backgroundImage: u.photoURL == null ? null : NetworkImage(u.photoURL!),
        child: u.photoURL == null ? const Icon(Icons.person) : null),
      const SizedBox(height: 12), Text(u.displayName ?? 'مستخدم', textAlign: TextAlign.center, style: const TextStyle(fontSize: 20)),
      Text(u.email ?? '', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54)),
      const SizedBox(height: 24), const Text('اختر يوزر فريد'),
      TextField(controller: c, decoration: const InputDecoration(prefixText: '@', hintText: 'myname_123')),
      const SizedBox(height: 10), FilledButton(onPressed: busy ? null : save, child: Text(busy ? 'جارٍ الحفظ...' : 'حفظ اليوزر')),
      Text(note), const SizedBox(height: 18),
      const Text('هذه نسخة بداية. المكالمات والحالات بالوسائط تحتاج تطويراً إضافياً.')
    ]);
  }
}

class StatusPage extends StatefulWidget {
  const StatusPage({super.key});
  @override State<StatusPage> createState() => _StatusPageState();
}
class _StatusPageState extends State<StatusPage> {
  final c = TextEditingController();
  Future<void> addStatus() async {
    if (c.text.trim().isEmpty) return;
    final u = FirebaseAuth.instance.currentUser!;
    final p = await FirebaseFirestore.instance.collection('users').doc(u.uid).get();
    await FirebaseFirestore.instance.collection('statuses').add({
      'uid': u.uid, 'username': p.data()?['username'] ?? '',
      'text': c.text.trim(), 'createdAt': FieldValue.serverTimestamp()
    });
    c.clear();
  }
  @override
  Widget build(BuildContext context) => Column(children: [
    const ListTile(title: Text('الحالة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
    Padding(padding: const EdgeInsets.all(12), child: Row(children: [
      Expanded(child: TextField(controller: c, decoration: const InputDecoration(hintText: 'اكتب حالة أو رابط'))),
      IconButton(onPressed: addStatus, icon: const Icon(Icons.add_circle, color: green, size: 32))
    ])),
    const Divider(),
    Expanded(child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
      stream: FirebaseFirestore.instance.collection('statuses').orderBy('createdAt', descending: true).limit(50).snapshots(),
      builder: (_, s) {
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        if (s.data!.docs.isEmpty) return const Center(child: Text('لا توجد حالات بعد'));
        return ListView(children: s.data!.docs.map((d) => ListTile(
          leading: const CircleAvatar(child: Icon(Icons.bolt)), title: Text(d.data()['text'] ?? ''),
          subtitle: Text('@${d.data()['username'] ?? ''}'))).toList());
      }))
  ]);
}

void showCallNote(BuildContext context, String type) => showDialog(context: context, builder: (_) => AlertDialog(
  title: Text('مكالمة $type'),
  content: const Text('هذه الأزرار شكلية في النسخة الحالية. يلزم تنفيذ WebRTC وخادم إشارات STUN/TURN للمكالمات الحقيقية.'),
  actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسناً'))]));
